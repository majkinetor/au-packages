EMLView 1.2.6.5 Beta

Lister plugin for view e-mail message files (*.eml and *.msg).
This is new independent version of EML Viewer plugin (http://totalcmd.net/plugring/wlx_msg.html).

First plain text part will always shown (if not empty). If plain text part absent then first html part will be shown as text.
First html part can be shown in browser (without embedded images) and in separate tab as text.
For show and convert html standard WebBrowser Control (IE) is used.
All message part can be saved to empty folder.
Double empty text lines in main tab will be deleted. 


*** Installing ***

Just enter to archive with plugin and TC ask you about plugin installing. 


*** License agreement ***

  This software provided "AS-IS" without warranty of any kind for commercial or non-commercial use.


*** Changes history ***

Ver 1.1.2.2:
 * public version;
 + EMLView.ini for manual setup:
   [EMLView]
   CheckEmbeddedHTMLImages=0 - show embedded images (they will save to temp folder);
 * some fixes.

Ver 1.2:
 * updated eml parsing library;
 + EMLView.ini for manual setup:
   [EMLView]
   ShowStatusBar=1 - status bar visibility;
   StatusBarPanelsAutoSize=0 - status bar panels autosize;
   ExtendedHTMLasTextTrim=0 - delete superfluous spaces when convert text from HTML (affected to tab 'HTML as Text').
 * some fixes and changes.

Ver 1.2.1:
 * DetectString added;
 + EMLView.ini for manual setup:
   [EMLView]
   ShowAttachmentsTab=0 - show tab with attached files (view graphics, other as first 50k text (in browser));
   PageViewTabStyle=2 - tab type (0 - tabs, 1 - buttons, 2 - flat buttons);
 * more options in setup dialog;
 * some fixes and changes.

Ver 1.2.2:
 + EMLView.ini for manual setup:
   [EMLView]
   WordWrap=2 - on plugin start word wrap is (0 - enabled, 1 - disabled, 2 - auto);
 * some fixes and changes.

Ver 1.2.3:
 * memory leak fix.

Ver 1.2.3.1:
 * some fixes.

Ver 1.2.3.3:
 * some fixes.

Ver 1.2.4:
 * some HTML checks (embedded images, encoding) can hang plugin and TC;
 + when search embedded images first check attachments next other encoded parts;
 + EMLView.ini for manual setup:
   [EMLView]
   OpenHTMLPageOnStart=0 - on plugin start and quick view open 'WebBrowser' page;
 * some fixes.

Ver 1.2.5 Beta:
 + EMLView.ini for manual setup:
   [EMLView]
   Offline=0 - don't load images from Internet, links still work's.

Ver 1.2.6 Beta:
 + basic support for Outlook .MSG files.

Ver 1.2.6.1 Beta:
 + headers decoding fixes for .MSG files.

Ver 1.2.6.2 Beta:
 + search on main page.

Ver 1.2.6.3 Beta:
 + EMLView.ini for manual setup:
   [EMLView]
   NormalizeUnicodeChars=0 - normalize Unicode chars.

Ver 1.2.6.4 Beta:
 * changes in conversion HTML to text;
 * some fixes.

Ver 1.2.6.5 Beta:
 * fix display attached images in HTML;
 * some fixes.


---
Suggestions, Wishes and bug reports are welcome!
ProgMan13, (ProgMan13@mail.ru)