JSONViewer 1.2.2

Simple lister plugin for view JSON files (*.json).


*** Installing ***

  Just enter to archive with plugin and TC ask you about plugin installing. 


*** License agreement ***

  This software provided "AS-IS" without warranty of any kind for non-commercial use.


*** Changes history ***

Ver 0.9:
 * public version.
 
Ver 1.0:
 + Setup dialog;
 * changes and fixes.

Ver 1.1:
 + simple search;
 * fixes.

Ver 1.1.2:
 * fixes.

Ver 1.2:
 + option for show value as JSON string (with escape symbol "\" etc.);
 * fixed conversion of some values like very big numbers (just read as text, previously these files can't be opened in plugin);
 * fixes.

Ver 1.2.1:
  + JSONViewer.ini for manual setup:
   [JSONViewer]
   ShowOpenError=0 - show errors when try file open.

Ver 1.2.2:
 + option for unescape name (ex. for '50/50', was '50\/50');
 * fixes.


---
Suggestions, Wishes and bug reports are welcome!
ProgMan13, (ProgMan13@mail.ru)