CSVView 0.9.5.1 Beta

Lister plugin for view CSV files (*.csv).
This is new independed version of CSV Viewer plugin (http://totalcmd.net/plugring/wlx_csv.html).


*** Installing ***

Just enter to archive with plugin and TC ask you about plugin installing. 


*** License agrement ***

  This software provided "AS-IS" without warranty of any kind for commercial or non-commercial use.


*** Changes history ***

Ver 0.9 Beta:
 * public version.

Ver 0.9.1 Beta:
 + search;
 * ignoring non-printable chars by default (IgnoreSpecialCharacters and ConvertTabSpecialCharacter in ini);
 * changes and bug fixes.

Ver 0.9.2 Beta:
 + show row numbers (ShowRowNumber in ini, by default 1);
 * due to possible problems window updating disabled (LiveUpdate in ini, by default 0);
 * changes and bug fixes.

Ver 0.9.3 Beta:
 + sorting considering numbers (NumericSort in ini, by default 0);
 * changes and bug fixes.

Ver 0.9.3.1 Beta:
 + font setup (FontName and FontSize in ini).

Ver 0.9.3.2 Beta:
 * fixed error when null character in text appear.

Ver 0.9.3.3 Beta:
 * bug fixes.

Ver 0.9.4 Beta:
 + max file size for open, in Megabytes (MaxFileSize in ini, by default 10);
 * changed some default values;
 + read plugin ini on every plugin start (RereadINI in ini, by default 0);
 * bug fixes.

Ver 0.9.5 Beta
 + remove ALL double quotes in string (DequoteFields in ini, by default 1);
 + try all separators and select first in string, else separator priority (AdvancedFindSeparator in ini, by default 1);
 + possible separators, not empty value (Separators in ini, by default: "T;|," without quotes. T - tab char);
 * changes and bug fixes.

Ver 0.9.5.1 Beta
 + even row color (DrawEvenRowColor in ini, by default 1. And color itself in GridEvenRowColor);
 * font size fixes.


---
Suggestions, Wishes and bug reports are welcome!
ProgMan13, (ProgMan13@mail.ru)